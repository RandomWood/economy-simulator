namespace Roblox.Dto.Users;

public class SetStatusRequest
{
    public string status { get; set; }
}