using Microsoft.AspNetCore.Mvc.RazorPages;
using Roblox.Models.Sessions;

namespace Roblox.Website.Pages;

public class Home : RobloxPageModel
{
    public void OnGet()
    {

    }
}