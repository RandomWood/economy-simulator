namespace Roblox.Services.Exceptions;

public class FloodcheckException : System.Exception
{
    
}