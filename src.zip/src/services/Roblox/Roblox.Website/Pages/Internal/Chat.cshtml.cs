using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Roblox.Website.Pages.Internal;

public class Chat : RobloxPageModel
{
    public void OnGet()
    {
        
    }
}