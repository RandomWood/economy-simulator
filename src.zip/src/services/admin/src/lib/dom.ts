export const getElementById = (id) => {
	return document.getElementById(id) as any;
}