namespace Roblox.Website.WebsiteModels.Users;

public class PresenceRequest
{
    public IEnumerable<long> userIds { get; set; }
}