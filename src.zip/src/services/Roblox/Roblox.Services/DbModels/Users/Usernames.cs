namespace Roblox.Services.DbModels;

public class PreviousUsernameEntries
{
    public long userId { get; set; }
    public string username { get; set; }
}

