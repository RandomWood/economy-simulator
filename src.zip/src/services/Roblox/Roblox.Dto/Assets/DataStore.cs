namespace Roblox.Dto.Assets;

public class DataStoreEntry
{
    public long id { get; set; }
    public string? value { get; set; }
}