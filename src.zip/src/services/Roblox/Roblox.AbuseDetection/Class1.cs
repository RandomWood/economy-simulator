﻿namespace Roblox.AbuseDetection;

public class Class1
{
}